public abstract class Creature {   
    String attack;
    int damage = 0;
    String what;
    // static members belong to class (instead of its instance).
    static int population = 0; 
    public abstract void action();    
    public static void main(String[] args) {        
        Dragon special = new Dragon("special", 3900);
        Dragon rathian = new Dragon("fire", 900);
        System.out.println(special.attack);
        System.out.println(rathian.damage);
        rathian.action();
        System.out.println("Number of creatures: " + population);
        // 'population' was a static variable.
        // try printing non-static member such as 'attack' or 'damage'.
    }
}
