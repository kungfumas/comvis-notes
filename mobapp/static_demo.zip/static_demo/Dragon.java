public class Dragon extends Creature {
    // 'extends', 'this'
    Dragon(String att, int dmg) {
        this.attack = att;
        this.damage = dmg;
        this.what = "a dragon.";
        population++;            
    }    
    public void action() {
        System.out.println("It breathes fire!");
    }
}